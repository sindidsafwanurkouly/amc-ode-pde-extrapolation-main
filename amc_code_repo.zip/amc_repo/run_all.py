#!/usr/bin/env python3
"""Top-level entry point. Regenerates all results and tables.

Usage: python run_all.py
"""
import subprocess, sys, os

HERE = os.path.dirname(os.path.abspath(__file__))

if __name__ == "__main__":
    subprocess.check_call([sys.executable, os.path.join(HERE, "code", "run_all.py")])
    subprocess.check_call([sys.executable, os.path.join(HERE, "code", "run_order8.py")])
    subprocess.check_call([sys.executable, os.path.join(HERE, "journal", "make_journal.py")])
    print("All results and tables regenerated.")
