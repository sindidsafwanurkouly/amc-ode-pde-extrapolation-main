# Code and results — Extrapolation and convergence analysis of ODE and PDE solvers

This repository accompanies the manuscript *"Extrapolation and convergence
analysis of ODE and PDE solvers"* (Md Sindid Safwanur Kouly, Md. Abdur
Rahman, Mostak Ahmed), submitted to *Applied Mathematics and Computation*.

## Contents

- `code/ode_solvers.py` — Euler, RK4, ABM4 (PECE, RK4-started), the
  four-step predictor–corrector method of Paper 5.
- `code/pde_solvers.py` — FTCS, backward Euler, Crank–Nicolson for the 1D
  and 2D heat equation; upwind and Lax–Wendroff for linear advection; an
  explicit central-difference scheme for the viscous Burgers equation.
- `code/extrapolate.py` — general Richardson/Romberg extrapolation for an
  arbitrary exponent sequence, plus observed-order and gain utilities.
- `code/run_all.py`, `code/run_order8.py` — experiment drivers; write
  JSON results to `results/`.
- `journal/make_journal.py` — regenerates a Markdown summary of the key
  tables from the saved JSON results.
- `run_all.py` — top-level entry point (runs both of the above).

## Regenerating the results

```
pip install numpy scipy mpmath matplotlib
python run_all.py
```

This writes `results/*.json` and `journal/tables.md`.

## Provenance note

The original code and saved results that produced the manuscript's figures
and tables were lost before submission. This repository is a careful
**reconstruction from the manuscript text**: every solver and every
extrapolation step was implemented directly from the formulas given in the
paper (Section 3), and run to check whether the stated numbers reproduce.

### What was verified against the manuscript's own printed tables

The following were checked line-by-line and match the paper to the
printed number of digits:

- **Table 9** (Euler/RK4 on P1, plain and extrapolated errors, observed
  orders, gains) — exact match.
- **Table 2 / Table 14** (1D heat equation, FTCS/backward Euler/
  Crank–Nicolson plain errors and observed orders) — exact match.
- **Table 16** (2D heat equation, Paper 4 setting) — exact match.
- **Paper 2, Example 1 (P2.1), RK4** mean absolute error at h=0.02 and
  h=0.0025 — exact match to the paper's own comparison against the
  external Paper 2 (Table 8).
- **Table 21 / order-8 repeated extrapolation** on P1 with RK4 — levels 1
  to 3 match to 2–3 decimal places; the level-4 (order ~8) value is
  round-off-dominated, so small machine-to-machine differences are
  expected here and are explicitly discussed in the paper itself
  (Section 7.2).

### What was approximately but not exactly reproduced

- The nonlinear ODE problems (N1, N2, N3) and the remaining Paper 2
  examples (P2.2, P2.3) reproduce the same qualitative orders and gains,
  but not always to the same decimal, because the manuscript does not
  state the exact starting step size h0 used for every problem — only
  the final time T. Different reasonable choices of h0 shift the printed
  decimals slightly without changing the conclusions.

### What was not independently re-verified in this reconstruction

Given the scope of the original study (24 tables, 7 figures, ~10 methods,
comparisons against three external papers' exact printed digits, and
50/90-digit arbitrary-precision arithmetic), the following were
implemented but not individually checked against every printed digit in
the manuscript:

- The stiff Prothero–Robinson problem (Table 12).
- The four-step predictor–corrector method of Paper 5 (Tables 4, 13) and
  its parasitic-root behaviour (Fig. 4).
- Linear advection with discontinuous data, and the viscous Burgers
  equation (Tables 19–20).
- The work–precision comparison against SciPy's RK45/DOP853 (Fig. 7).
- The 90-digit synthetic check of the error-constant formula (Table 1).

**Before this repository's link is submitted with the manuscript, the
authors should re-run `run_all.py`, compare the regenerated numbers
against every table in `main_elsevier.tex`, and correct any table whose
printed numbers do not match genuine computed output.** The paper's text
must reflect what the code actually produces, not the reverse.
