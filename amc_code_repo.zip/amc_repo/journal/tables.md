# Regenerated tables

## Table 9 — Paper 1 (Euler/RK4 on P1)

**euler**
plain errors: 9.482e-01, 5.316e-01, 2.826e-01, 1.459e-01
plain observed orders: 0.83, 0.91, 0.95
level-1 errors: 1.149e-01, 3.367e-02, 9.158e-03
level-1 observed orders: 1.77, 1.88
gain (level 1): 4.6x, 8.4x, 15.9x

**rk4**
plain errors: 1.627e-04, 1.106e-05, 7.210e-07, 4.602e-08
plain observed orders: 3.88, 3.94, 3.97
level-1 errors: 9.514e-07, 3.170e-08, 1.023e-09
level-1 observed orders: 4.91, 4.95
gain (level 1): 11.6x, 22.7x, 45.0x

## Table 14 — 1D heat equation (FTCS / backward Euler / Crank-Nicolson)

**ftcs**
plain errors: 2.486e-02, 6.164e-03, 1.520e-03, 3.786e-04, 9.457e-05
plain observed orders: 2.01, 2.02, 2.00, 2.00

**be**
plain errors: 4.243e-02, 1.185e-02, 3.009e-03, 7.553e-04, 1.890e-04
plain observed orders: 1.84, 1.98, 1.99, 2.00

**cn**
plain errors: 1.048e-02, 2.954e-03, 7.519e-04, 1.888e-04, 4.725e-05
plain observed orders: 1.83, 1.97, 1.99, 2.00

## Table 16 — 2D heat equation (FTCS, Paper 4 setting)

errors: 5.534e-10, 1.485e-10, 3.778e-11, 9.487e-12, 2.374e-12
observed orders: 1.90, 1.97, 1.99, 2.00

## Paper 2 problems (RK4/ABM4, mean absolute error)

**P2.1**
rk4 MAE: 7.577e-06, 3.269e-07, 1.683e-08, 9.514e-10, 5.651e-11
rk4 observed orders: 4.53, 4.28, 4.14, 4.07
abm4 MAE: 3.765e-05, 1.409e-06, 6.693e-08, 3.436e-09, 1.910e-10
abm4 observed orders: 4.74, 4.40, 4.28, 4.17

**P2.2**
rk4 MAE: 2.554e-10, 1.594e-11, 9.676e-13, 3.231e-14, 2.261e-13
rk4 observed orders: 4.00, 4.04, 4.90, -2.81
abm4 MAE: 9.528e-10, 6.690e-11, 4.457e-12, 3.148e-13, 2.023e-13
abm4 observed orders: 3.83, 3.91, 3.82, 0.64

**P2.3**
rk4 MAE: 8.594e-11, 5.370e-12, 3.341e-13, 1.890e-14, 2.626e-15
rk4 observed orders: 4.00, 4.01, 4.14, 2.85
abm4 MAE: 1.000e-09, 6.158e-11, 3.824e-12, 2.403e-13, 1.737e-14
abm4 observed orders: 4.02, 4.01, 3.99, 3.79
