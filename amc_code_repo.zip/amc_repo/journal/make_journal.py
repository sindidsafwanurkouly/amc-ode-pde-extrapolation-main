"""
Regenerates the paper's key result tables (as Markdown) from results/*.json.
Run after code/run_all.py. This is a representative subset of the full
paper's 24 tables -- see README.md for which ones are included.
"""
import json, os

RESULTS = os.path.join(os.path.dirname(__file__), "..", "results")
OUT = os.path.join(os.path.dirname(__file__), "tables.md")


def load(name):
    with open(os.path.join(RESULTS, name + ".json")) as fh:
        return json.load(fh)


def fmt(x, sig=3):
    try:
        return f"{x:.{sig}e}"
    except Exception:
        return str(x)


def main():
    lines = ["# Regenerated tables\n"]

    t9 = load("table9_paper1")
    lines.append("## Table 9 — Paper 1 (Euler/RK4 on P1)\n")
    for name in ["euler", "rk4"]:
        d = t9[name]
        lines.append(f"**{name}**")
        lines.append("plain errors: " + ", ".join(fmt(e) for e in d["errors"]))
        lines.append("plain observed orders: " + ", ".join(f"{o:.2f}" for o in d["observed_orders"]))
        lines.append("level-1 errors: " + ", ".join(fmt(e) for e in d["level1_errors"]))
        lines.append("level-1 observed orders: " + ", ".join(f"{o:.2f}" for o in d["level1_orders"]))
        lines.append("gain (level 1): " + ", ".join(f"{g:.1f}x" for g in d["gain1"]))
        lines.append("")

    h1 = load("heat1d_table14")
    lines.append("## Table 14 — 1D heat equation (FTCS / backward Euler / Crank-Nicolson)\n")
    for scheme in ["ftcs", "be", "cn"]:
        d = h1[scheme]
        lines.append(f"**{scheme}**")
        lines.append("plain errors: " + ", ".join(fmt(e) for e in d["errors"]))
        lines.append("plain observed orders: " + ", ".join(f"{o:.2f}" for o in d["orders"]))
        lines.append("")

    h2 = load("heat2d_table16")
    lines.append("## Table 16 — 2D heat equation (FTCS, Paper 4 setting)\n")
    lines.append("errors: " + ", ".join(fmt(e) for e in h2["errors"]))
    lines.append("observed orders: " + ", ".join(f"{o:.2f}" for o in h2["orders"]))
    lines.append("")

    p2 = load("paper2_odes")
    lines.append("## Paper 2 problems (RK4/ABM4, mean absolute error)\n")
    for name, entry in p2.items():
        lines.append(f"**{name}**")
        for m in ["rk4", "abm4"]:
            lines.append(f"{m} MAE: " + ", ".join(fmt(e) for e in entry[m]["mae"]))
            lines.append(f"{m} observed orders: " + ", ".join(f"{o:.2f}" for o in entry[m]["observed_orders"]))
        lines.append("")

    with open(OUT, "w") as fh:
        fh.write("\n".join(lines))
    print(f"wrote {OUT}")


if __name__ == "__main__":
    main()
