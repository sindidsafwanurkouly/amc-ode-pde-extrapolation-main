"""PDE solvers: 1D/2D heat equation (FTCS, backward Euler, Crank-Nicolson),
linear advection (upwind, Lax-Wendroff), viscous Burgers (explicit central)."""
import numpy as np
from scipy.linalg import solve_banded


def heat1d_ftcs(u0_func, N, r, nsteps):
    h = 1.0 / N
    x = np.linspace(0, 1, N + 1)
    u = u0_func(x)
    u[0] = 0.0
    u[-1] = 0.0
    for _ in range(nsteps):
        un = u.copy()
        u[1:-1] = un[1:-1] + r * (un[2:] - 2 * un[1:-1] + un[:-2])
        u[0] = 0.0
        u[-1] = 0.0
    return x, u


def _tridiag_solve(a, b, c, d):
    # a: sub, b: diag, c: super, d: rhs, interior unknowns only
    n = len(d)
    ab = np.zeros((3, n))
    ab[0, 1:] = c[:-1]
    ab[1, :] = b
    ab[2, :-1] = a[1:]
    return solve_banded((1, 1), ab, d)


def heat1d_backward_euler(u0_func, N, r, nsteps):
    h = 1.0 / N
    x = np.linspace(0, 1, N + 1)
    u = u0_func(x)
    u[0] = 0.0
    u[-1] = 0.0
    m = N - 1
    a = -r * np.ones(m)
    b = (1 + 2 * r) * np.ones(m)
    c = -r * np.ones(m)
    for _ in range(nsteps):
        d = u[1:-1].copy()
        interior = _tridiag_solve(a, b, c, d)
        u[1:-1] = interior
        u[0] = 0.0
        u[-1] = 0.0
    return x, u


def heat1d_crank_nicolson(u0_func, N, r, nsteps):
    h = 1.0 / N
    x = np.linspace(0, 1, N + 1)
    u = u0_func(x)
    u[0] = 0.0
    u[-1] = 0.0
    m = N - 1
    a = -(r / 2) * np.ones(m)
    b = (1 + r) * np.ones(m)
    c = -(r / 2) * np.ones(m)
    for _ in range(nsteps):
        un = u.copy()
        rhs = (r / 2) * un[:-2] + (1 - r) * un[1:-1] + (r / 2) * un[2:]
        interior = _tridiag_solve(a, b, c, rhs)
        u[1:-1] = interior
        u[0] = 0.0
        u[-1] = 0.0
    return x, u


def heat2d_ftcs(u0_func, N, S, nsteps):
    h = 1.0 / N
    x = np.linspace(0, 1, N + 1)
    y = np.linspace(0, 1, N + 1)
    X, Y = np.meshgrid(x, y, indexing="ij")
    u = u0_func(X, Y)
    u[0, :] = u[-1, :] = u[:, 0] = u[:, -1] = 0.0
    for _ in range(nsteps):
        un = u.copy()
        lap = (un[2:, 1:-1] - 2 * un[1:-1, 1:-1] + un[:-2, 1:-1]) + \
              (un[1:-1, 2:] - 2 * un[1:-1, 1:-1] + un[1:-1, :-2])
        u[1:-1, 1:-1] = un[1:-1, 1:-1] + S * lap
        u[0, :] = u[-1, :] = u[:, 0] = u[:, -1] = 0.0
    return X, Y, u


def heat2d_rk4_lines(u0_func, N, dt, nsteps):
    """Method of lines: central differences in space, RK4 in time."""
    h = 1.0 / N
    x = np.linspace(0, 1, N + 1)
    y = np.linspace(0, 1, N + 1)
    X, Y = np.meshgrid(x, y, indexing="ij")
    u = u0_func(X, Y)

    def rhs(u):
        du = np.zeros_like(u)
        du[1:-1, 1:-1] = (
            (u[2:, 1:-1] - 2 * u[1:-1, 1:-1] + u[:-2, 1:-1]) +
            (u[1:-1, 2:] - 2 * u[1:-1, 1:-1] + u[1:-1, :-2])
        ) / h ** 2
        return du

    for _ in range(nsteps):
        k1 = rhs(u)
        k2 = rhs(u + dt / 2 * k1)
        k3 = rhs(u + dt / 2 * k2)
        k4 = rhs(u + dt * k3)
        u = u + (dt / 6) * (k1 + 2 * k2 + 2 * k3 + k4)
        u[0, :] = u[-1, :] = u[:, 0] = u[:, -1] = 0.0
    return X, Y, u


def heat1d_rk4_lines(u0_func, N, dt, nsteps):
    h = 1.0 / N
    x = np.linspace(0, 1, N + 1)
    u = u0_func(x)

    def rhs(u):
        du = np.zeros_like(u)
        du[1:-1] = (u[2:] - 2 * u[1:-1] + u[:-2]) / h ** 2
        return du

    for _ in range(nsteps):
        k1 = rhs(u)
        k2 = rhs(u + dt / 2 * k1)
        k3 = rhs(u + dt / 2 * k2)
        k4 = rhs(u + dt * k3)
        u = u + (dt / 6) * (k1 + 2 * k2 + 2 * k3 + k4)
        u[0] = 0.0
        u[-1] = 0.0
    return x, u


def advection_upwind(u0_func, N, sigma, nsteps):
    h = 1.0 / N
    x = np.linspace(0, 1, N, endpoint=False)
    u = u0_func(x)
    for _ in range(nsteps):
        u = u - sigma * (u - np.roll(u, 1))
    return x, u


def advection_lax_wendroff(u0_func, N, sigma, nsteps):
    h = 1.0 / N
    x = np.linspace(0, 1, N, endpoint=False)
    u = u0_func(x)
    for _ in range(nsteps):
        up = np.roll(u, -1)
        um = np.roll(u, 1)
        u = u - (sigma / 2) * (up - um) + (sigma ** 2 / 2) * (up - 2 * u + um)
    return x, u


def burgers_ftcs(u0_func, N, nu, r, dt_over_h, nsteps):
    h = 1.0 / N
    x = np.linspace(0, 1, N, endpoint=False)
    u = u0_func(x)
    dt = r * h ** 2
    for _ in range(nsteps):
        up = np.roll(u, -1)
        um = np.roll(u, 1)
        u = u - (dt / (2 * h)) * u * (up - um) + nu * r * (up - 2 * u + um)
    return x, u
