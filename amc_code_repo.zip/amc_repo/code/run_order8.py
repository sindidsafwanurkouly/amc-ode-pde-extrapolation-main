"""Repeated extrapolation to order ~8 on P1 with RK4 (Table 21, Table 1 style
check). Reproduces the paper's headline "observed order close to 8" claim."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from ode_solvers import rk4
from extrapolate import romberg_table, observed_orders

def f(t, y):
    y1, y2 = y
    return np.array([y2, 3 * y2 - 2 * y1])

y0 = np.array([-1.0, 0.0])
exact = np.exp(2.0) - 2 * np.exp(1.0)
hs = [0.2 / 2 ** k for k in range(8)]
vals = [rk4(f, 0.0, y0, h, round(1.0 / h))[0] for h in hs]
errs = [abs(v - exact) for v in vals]
table = romberg_table(vals, list(range(4, 11)))

out = {"h": hs, "plain_errors": errs, "plain_orders": observed_orders(errs)}
for lvl in range(1, len(table)):
    le = [abs(v - exact) for v in table[lvl]]
    out[f"level{lvl}_errors"] = le
    out[f"level{lvl}_orders"] = observed_orders(le)

RESULTS = os.path.join(os.path.dirname(__file__), "..", "results")
with open(os.path.join(RESULTS, "order8_ode.json"), "w") as fh:
    json.dump(out, fh, indent=2, default=float)

print("Plain orders:", [f"{o:.3f}" for o in out["plain_orders"]])
for lvl in range(1, 5):
    key = f"level{lvl}_orders"
    if key in out:
        print(f"Level {lvl} orders:", [f"{o:.3f}" for o in out[key]])
print("Note: the order-8 (level-4) value is round-off dominated and will")
print("differ slightly machine-to-machine; the paper itself notes this")
print("(Section 7.2) and reports 7.65 in double precision vs 8.11 with")
print("50-digit mpmath arithmetic.")
