"""
Regenerates all saved results for:
"Extrapolation and convergence analysis of ODE and PDE solvers"

Run: python code/run_all.py
Writes JSON files to results/.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from ode_solvers import euler, rk4, abm4, pc4_paper5
from pde_solvers import (heat1d_ftcs, heat1d_backward_euler, heat1d_crank_nicolson,
                          heat2d_ftcs, heat1d_rk4_lines, heat2d_rk4_lines,
                          advection_upwind, advection_lax_wendroff, burgers_ftcs)
from extrapolate import romberg_table, observed_orders

RESULTS = os.path.join(os.path.dirname(__file__), "..", "results")
os.makedirs(RESULTS, exist_ok=True)


def save(name, data):
    with open(os.path.join(RESULTS, name + ".json"), "w") as fh:
        json.dump(data, fh, indent=2, default=float)
    print(f"wrote results/{name}.json")


# ---------- Table 9: Paper 1 (P1) Euler/RK4 ----------
def table9():
    def f(t, y):
        y1, y2 = y
        return np.array([y2, 3 * y2 - 2 * y1])
    y0 = np.array([-1.0, 0.0])
    exact = np.exp(2.0) - 2 * np.exp(1.0)
    hs = [0.1, 0.05, 0.025, 0.0125]
    out = {"exact": exact, "h": hs}
    for name, solver, p in [("euler", euler, 1), ("rk4", rk4, 4)]:
        values = [solver(f, 0.0, y0, h, round(1.0 / h))[0] for h in hs]
        errs = [abs(v - exact) for v in values]
        table = romberg_table(values, [p, p + 1, p + 2])
        l1 = [abs(v - exact) for v in table[1]]
        l2 = [abs(v - exact) for v in table[2]] if len(table) > 2 else []
        out[name] = {
            "values": values, "errors": errs, "observed_orders": observed_orders(errs),
            "level1_errors": l1, "level1_orders": observed_orders(l1),
            "level2_errors": l2, "level2_orders": observed_orders(l2),
            "gain1": [errs[i + 1] / l1[i] for i in range(len(l1))],
        }
    save("table9_paper1", out)
    return out


# ---------- Paper 2 problems (Table 8, 10) ----------
def mae_solver(solver, f, t0, y0, h, n, exact_fn):
    y = np.array(y0, dtype=float)
    t = t0
    errs = []
    for _ in range(n):
        y = solver(f, t, y, h, 1) if False else None
    return None  # replaced by direct stepping below


def rk4_mae_traj(f, t0, y0, h, n, exact_fn):
    y = np.array(y0, dtype=float)
    t = t0
    errs = []
    for _ in range(n):
        k1 = np.asarray(f(t, y)); k2 = np.asarray(f(t + h / 2, y + h / 2 * k1))
        k3 = np.asarray(f(t + h / 2, y + h / 2 * k2)); k4 = np.asarray(f(t + h, y + h * k3))
        y = y + (h / 6) * (k1 + 2 * k2 + 2 * k3 + k4)
        t = t + h
        errs.append(abs(y[0] - exact_fn(t)))
    return np.mean(errs), y[0]


def abm4_mae_traj(f, t0, y0, h, n, exact_fn):
    y = np.array(y0, dtype=float); t = t0
    ys, ts, fs, errs = [y], [t], [], []
    for i in range(min(3, n)):
        fs.append(np.asarray(f(t, y)))
        k1 = fs[-1]; k2 = np.asarray(f(t + h / 2, y + h / 2 * k1))
        k3 = np.asarray(f(t + h / 2, y + h / 2 * k2)); k4 = np.asarray(f(t + h, y + h * k3))
        y = y + (h / 6) * (k1 + 2 * k2 + 2 * k3 + k4); t = t + h
        ys.append(y); ts.append(t); errs.append(abs(y[0] - exact_fn(t)))
    if n > 3:
        fs.append(np.asarray(f(t, y)))
        for i in range(3, n):
            fn, fnm1, fnm2, fnm3 = fs[-1], fs[-2], fs[-3], fs[-4]
            yp = y + (h / 24) * (55 * fn - 59 * fnm1 + 37 * fnm2 - 9 * fnm3)
            fnp1p = np.asarray(f(t + h, yp))
            y = y + (h / 24) * (9 * fnp1p + 19 * fn - 5 * fnm1 + fnm2)
            t = t + h
            fs.append(np.asarray(f(t, y)))
            errs.append(abs(y[0] - exact_fn(t)))
    return np.mean(errs), y[0]


def paper2():
    def f1(t, y): return np.array([np.exp(-2 * t) - 50 * y[0]])
    def exact1(t): return (np.exp(-2 * t) - np.exp(-50 * t)) / 48
    def f2(t, y): return np.array([4 * np.log(t) + y[0] / t])
    def exact2(t): return t + 2 * t * np.log(t) ** 2
    def f3(t, y): return np.array([(1 - t) * y[0] ** 2 - y[0]])
    def exact3(t): return 1.0 / (np.exp(t) - t)

    problems = {
        "P2.1": (f1, [0.0], 0.0, 1.0, exact1, [0.02, 0.01, 0.005, 0.0025, 0.00125]),
        "P2.2": (f2, [1.0], 1.0, 2.0, exact2, [0.01, 0.005, 0.0025, 0.00125, 0.000625]),
        "P2.3": (f3, [1.0], 0.0, 1.0, exact3, [0.01, 0.005, 0.0025, 0.00125, 0.000625]),
    }
    out = {}
    for name, (f, y0, t0, t1, exact_fn, hs) in problems.items():
        entry = {"h": hs}
        for mname, maefun in [("rk4", rk4_mae_traj), ("abm4", abm4_mae_traj)]:
            maes, finals = [], []
            for h in hs:
                n = round((t1 - t0) / h)
                mae, final = maefun(f, t0, y0, h, n, exact_fn)
                maes.append(mae); finals.append(final)
            orders = observed_orders(maes)
            p = 4
            exps = list(range(p, p + len(maes)))
            table = romberg_table(maes, exps)
            l1 = table[1] if len(table) > 1 else []
            out_entry = {"mae": maes, "observed_orders": orders, "level1_mae": l1,
                         "level1_orders": observed_orders(l1)}
            entry[mname] = out_entry
        out[name] = entry
    save("paper2_odes", out)
    return out


# ---------- Nonlinear ODEs (Table 11) ----------
def nonlinear():
    def flog(t, y): return np.array([y[0] * (1 - y[0])])
    def exlog(t): return 1.0 / (1 + 9 * np.exp(-t))
    def fn2(t, y): return np.array([-2 * t * y[0] ** 2])
    def exn2(t): return 1.0 / (1 + t ** 2)

    out = {}
    # logistic, Euler and RK4, T=5
    hs = [5.0 / (10 * 2 ** k) for k in range(5)]
    for mname, solver, p in [("euler", euler, 1), ("rk4", rk4, 4)]:
        vals = [solver(flog, 0.0, np.array([0.1]), h, round(5.0 / h))[0] for h in hs]
        ex = exlog(5.0)
        errs = [abs(v - ex) for v in vals]
        table = romberg_table(vals, [p, p + 1, p + 2, p + 3][:len(vals)-1])
        l1 = [abs(v - ex) for v in table[1]]
        l2 = [abs(v - ex) for v in table[2]] if len(table) > 2 else []
        out[f"logistic_{mname}"] = {"h": hs, "errors": errs, "orders": observed_orders(errs),
                                      "level1_errors": l1, "level1_orders": observed_orders(l1),
                                      "level2_errors": l2, "level2_orders": observed_orders(l2)}
    # N2, RK4, T=3
    hs2 = [3.0 / (10 * 2 ** k) for k in range(5)]
    vals = [rk4(fn2, 0.0, np.array([1.0]), h, round(3.0 / h))[0] for h in hs2]
    ex2 = exn2(3.0)
    errs = [abs(v - ex2) for v in vals]
    table = romberg_table(vals, [4,5,6,7][:len(vals)-1])
    l1 = [abs(v - ex2) for v in table[1]]
    l2 = [abs(v - ex2) for v in table[2]] if len(table) > 2 else []
    out["N2_rk4"] = {"h": hs2, "errors": errs, "orders": observed_orders(errs),
                      "level1_errors": l1, "level1_orders": observed_orders(l1),
                      "level2_errors": l2, "level2_orders": observed_orders(l2)}
    save("nonlinear_odes", out)
    return out


# ---------- 1D heat equation Table 2 & 14 ----------
def heat1d():
    def u0(x): return np.sin(np.pi * x)
    T, r = 0.1, 0.5
    Ns = [5, 10, 20, 40, 80]
    out = {"N": Ns}
    for name, solver in [("ftcs", heat1d_ftcs), ("be", heat1d_backward_euler), ("cn", heat1d_crank_nicolson)]:
        grids = []
        errs = []
        for N in Ns:
            h = 1.0 / N; dt = r * h * h; n = round(T / dt)
            exact = np.exp(-np.pi ** 2 * T) * np.sin(np.pi * np.linspace(0, 1, N + 1))
            x, u = solver(u0, N, r, n)
            grids.append(u)
            errs.append(float(np.max(np.abs(u - exact))))
        orders = observed_orders(errs)
        # extrapolate on coarsest common grid: sample finer grids at coarse nodes (every 2^k-th point)
        N0 = Ns[0]
        coarse_exact = np.exp(-np.pi ** 2 * T) * np.sin(np.pi * np.linspace(0, 1, N0 + 1))
        sampled = []
        for i, N in enumerate(Ns):
            step = N // N0
            sampled.append(grids[i][::step])
        table = romberg_table(sampled, [2, 2, 2, 2])
        l1 = [float(np.max(np.abs(v - coarse_exact))) for v in table[1]] if len(table) > 1 else []
        l2 = [float(np.max(np.abs(v - coarse_exact))) for v in table[2]] if len(table) > 2 else []
        out[name] = {"errors": errs, "orders": orders,
                      "level1_errors": l1, "level1_orders": observed_orders(l1),
                      "level2_errors": l2, "level2_orders": observed_orders(l2)}
    save("heat1d_table14", out)
    return out


# ---------- 2D heat equation Table 16/17 ----------
def heat2d():
    def u0(X, Y): return np.sin(np.pi * X) * np.sin(np.pi * Y)
    S, T = 0.2, 1.0
    Ns = [10, 20, 40, 80, 160]
    errs = []
    for N in Ns:
        h = 1.0 / N; dt = S * h * h; n = round(T / dt)
        x = np.linspace(0, 1, N + 1)
        X, Y = np.meshgrid(x, x, indexing="ij")
        exact = np.exp(-2 * np.pi ** 2 * T) * np.sin(np.pi * X) * np.sin(np.pi * Y)
        _, _, u = heat2d_ftcs(u0, N, S, n)
        errs.append(float(np.max(np.abs(u - exact))))
    out = {"N": Ns, "errors": errs, "orders": observed_orders(errs)}
    save("heat2d_table16", out)
    return out


if __name__ == "__main__":
    print("Table 9 (Paper 1):"); t9 = table9()
    print({k: v for k, v in t9.items() if k != "euler" and k != "rk4"})
    print("Paper 2 ODEs:"); p2 = paper2()
    print("Nonlinear ODEs:"); nl = nonlinear()
    print("1D heat:"); h1 = heat1d()
    print("2D heat:"); h2 = heat2d()
    print("DONE")
