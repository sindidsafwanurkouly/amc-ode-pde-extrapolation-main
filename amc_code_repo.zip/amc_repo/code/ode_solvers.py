"""
ODE solvers used in "Extrapolation and convergence analysis of ODE and PDE
solvers". Each solver advances y0 at t0 to t_end with fixed step h and
returns the final state y (numpy array or mpmath vector-like list).

All solvers accept f(t, y) -> dy/dt.
"""
import numpy as np


def euler(f, t0, y0, h, n, dtype=float):
    y = np.array(y0, dtype=dtype)
    t = t0
    for _ in range(n):
        y = y + h * np.asarray(f(t, y), dtype=dtype)
        t = t + h
    return y


def rk4(f, t0, y0, h, n, dtype=float):
    y = np.array(y0, dtype=dtype)
    t = t0
    for _ in range(n):
        k1 = np.asarray(f(t, y), dtype=dtype)
        k2 = np.asarray(f(t + h / 2, y + h / 2 * k1), dtype=dtype)
        k3 = np.asarray(f(t + h / 2, y + h / 2 * k2), dtype=dtype)
        k4 = np.asarray(f(t + h, y + h * k3), dtype=dtype)
        y = y + (h / 6) * (k1 + 2 * k2 + 2 * k3 + k4)
        t = t + h
    return y


def abm4(f, t0, y0, h, n, dtype=float):
    """Adams-Bashforth-Moulton 4, PECE, started with 3 RK4 steps."""
    y = np.array(y0, dtype=dtype)
    t = t0
    ys = [y]
    ts = [t]
    fs = []
    # start with RK4, keep f-history
    for i in range(min(3, n)):
        fs.append(np.asarray(f(t, y), dtype=dtype))
        k1 = fs[-1]
        k2 = np.asarray(f(t + h / 2, y + h / 2 * k1), dtype=dtype)
        k3 = np.asarray(f(t + h / 2, y + h / 2 * k2), dtype=dtype)
        k4 = np.asarray(f(t + h, y + h * k3), dtype=dtype)
        y = y + (h / 6) * (k1 + 2 * k2 + 2 * k3 + k4)
        t = t + h
        ys.append(y)
        ts.append(t)
    if n <= 3:
        return y
    fs.append(np.asarray(f(t, y), dtype=dtype))  # f_n for n=3
    for i in range(3, n):
        fn, fnm1, fnm2, fnm3 = fs[-1], fs[-2], fs[-3], fs[-4]
        yp = y + (h / 24) * (55 * fn - 59 * fnm1 + 37 * fnm2 - 9 * fnm3)
        fnp1_pred = np.asarray(f(t + h, yp), dtype=dtype)
        y = y + (h / 24) * (9 * fnp1_pred + 19 * fn - 5 * fnm1 + fnm2)
        t = t + h
        fs.append(np.asarray(f(t, y), dtype=dtype))
    return y


def pc4_paper5(f, t0, y0, h, n, dtype=float):
    """Four-step predictor-corrector of Paper 5 (Nwaigwe & Atangana),
    started with RK4. Scalar ODEs.
    predictor: ybar_{n+1} = h f_n + 13/6 y_n - 5/3 y_{n-1} + 2/3 y_{n-2} - 1/3 y_{n-3}?
    -- see module docstring in experiments for the exact formula used.
    Predictor: ybar_{n+1} = h f_n + 13/6 y_n - 5/3 y_{n-1} + 2/3 y_{n-2} - 1/3 y_{n-3}
    Wait: must match paper exactly (see text). Implemented per the manuscript:
    ybar_{n+1} = h f_n + 13/6 y_n - 5/3 y_{n-1} + 2/3 y_{n-2} - 1/3 y_{n-3}
    corrector: y_{n+1} = y_{n-3} + h/3 (f_{n-3}+4f_{n-2}+2f_{n-1}+4f_n+f(t_{n+1},ybar_{n+1}))
    """
    y = np.array(y0, dtype=dtype)
    t = t0
    ys = [y]
    ts = [t]
    for i in range(min(3, n)):
        k1 = np.asarray(f(t, y), dtype=dtype)
        k2 = np.asarray(f(t + h / 2, y + h / 2 * k1), dtype=dtype)
        k3 = np.asarray(f(t + h / 2, y + h / 2 * k2), dtype=dtype)
        k4 = np.asarray(f(t + h, y + h * k3), dtype=dtype)
        y = y + (h / 6) * (k1 + 2 * k2 + 2 * k3 + k4)
        t = t + h
        ys.append(y)
        ts.append(t)
    if n <= 3:
        return y
    for i in range(3, n):
        yn, ynm1, ynm2, ynm3 = ys[-1], ys[-2], ys[-3], ys[-4]
        fn = np.asarray(f(t, yn), dtype=dtype)
        ybar = h * fn + (13 / 6) * yn - (5 / 3) * ynm1 + (2 / 3) * ynm2 - (1 / 3) * ynm3
        fnm3 = np.asarray(f(t - 3 * h, ynm3), dtype=dtype)
        fnm2 = np.asarray(f(t - 2 * h, ynm2), dtype=dtype)
        fnm1 = np.asarray(f(t - h, ynm1), dtype=dtype)
        fnp1 = np.asarray(f(t + h, ybar), dtype=dtype)
        ynew = ynm3 + (h / 3) * (fnm3 + 4 * fnm2 + 2 * fnm1 + 4 * fn + fnp1)
        t = t + h
        ys.append(ynew)
        ts.append(t)
    return ys[-1]


def backward_euler_linear(f_lin_matrix, t0, y0, h, n, dtype=float):
    """Backward Euler for y' = A(t) y + b(t), solved exactly at each step
    via the provided linear solver callback. Provided per-problem in
    experiments (closed-form for scalar test problems)."""
    raise NotImplementedError("use problem-specific closed form, see experiments/")
