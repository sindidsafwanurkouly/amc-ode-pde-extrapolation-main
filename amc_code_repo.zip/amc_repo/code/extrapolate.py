"""
General Richardson / Romberg extrapolation given an asymptotic exponent
sequence q_1 < q_2 < ... (Assumption 1 of the paper).

A_m(h) = (2^{q_m} A_{m-1}(h/2) - A_{m-1}(h)) / (2^{q_m} - 1)
"""
import numpy as np


def romberg_table(values, exponents):
    """
    values: list of arrays/scalars A(h0), A(h0/2), ..., A(h0/2^M) (coarsest first)
    exponents: list q_1, q_2, ..., q_M (q_m used to produce level m from level m-1)
    returns: table[level][index] = extrapolated value using runs
             index..index+level of `values`
    table[0] = values (plain)
    table[m][i] built from table[m-1][i] and table[m-1][i+1]
    """
    M = len(values) - 1
    table = [list(values)]
    for m in range(1, M + 1):
        q = exponents[m - 1]
        factor = 2.0 ** q
        prev = table[m - 1]
        new_level = []
        for i in range(len(prev) - 1):
            coarse = prev[i]
            fine = prev[i + 1]
            val = (factor * fine - coarse) / (factor - 1)
            new_level.append(val)
        table.append(new_level)
    return table


def observed_orders(errors):
    """errors: list of ||A(h_i)-A|| for h_i = h0/2^i (coarsest first).
    returns list of obs(h_i) = log2(E(h_i)/E(h_i/2)) for consecutive pairs."""
    orders = []
    for i in range(len(errors) - 1):
        e0, e1 = errors[i], errors[i + 1]
        if e0 <= 0 or e1 <= 0:
            orders.append(float('nan'))
        else:
            orders.append(np.log2(e0 / e1))
    return orders


def gains(plain_errors_fine, extrap_errors):
    """gain_i = plain_error(h/2^(i+1)) / extrap_error_at_that_level."""
    g = []
    for pe, ee in zip(plain_errors_fine, extrap_errors):
        if ee == 0 or ee != ee:
            g.append(float('inf'))
        else:
            g.append(pe / ee)
    return g
